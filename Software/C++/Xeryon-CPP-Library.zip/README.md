# XeryonLib

## Building

Check `main.cpp` and make sure the correct COM port is selected.

### Linux/macOS

```
mkdir build
cd build
cmake ..
make
```

### Windows

**Command line**

Open a 'Developer Command Prompt' and enter these commands:

```
mkdir build
cd build
cmake .. -G"NMake Makefile"
nmake
```

**Visual Studio solution**

Open a 'Developer Command Prompt' and enter these commands:

```
mkdir build
cd build
cmake .. -G"Visual Studio 16 2019" -AWin64
-- or --
cmake .. -G"Visual Studio 15 2017 Win64"
```

This will generate a `Xeryon.sln` file in the `build` directory which can be opened by Visual Studio.
To be able to run the example, right-click on "ALL_BUILD" in the Solution Explorer, click "Properties", select "Debugging" and change "Command" to the `Xeryon_bin.exe` file.
